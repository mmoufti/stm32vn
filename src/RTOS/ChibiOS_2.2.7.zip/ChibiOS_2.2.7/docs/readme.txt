*** Documentation access ***

Open ./docs/index.html to open the start page or ./docs/html/index.html in
order to access directly the doxigen documentation.

*** Documentation build procedure ***

The following software must be installed:
- Doxygen 1.6.3 or later.
- Graphviz 2.21 or later. The ./bin directory must be specified in the path in
  order to make Graphviz accessible by Doxygen.

Build procedure:
- Run Doxywizard.
- Load ./docs/Doxyfile from Doxywizard.
- Start.
