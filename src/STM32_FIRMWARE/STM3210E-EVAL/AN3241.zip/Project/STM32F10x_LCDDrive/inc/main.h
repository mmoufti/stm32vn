/**
  ******************************************************************************
  * @file    main.h
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    07/07/2010
  * @brief   This file contains prototypes for main.c file
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 STMicroelectronics</center></h2>
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

/* Includes ------------------------------------------------------------------*/
#include "lcd_driver.h"
#include "stm3210e_eval_fsmc_sram.h"
#include "backlight_control.h"
#include "stm32_eval.h"


/** @addtogroup STM32F10x_LCD_Drive
  * @{
  */

/** @addtogroup STM32F10x_LCD_Drive_MAIN
  * @{
  */  

/** @defgroup STM32F10x_LCD_Drive_MAIN_Exported_Types
  * @{
  */ 
/**
  * @}
  */ 

/** @defgroup STM32F10x_LCD_Drive_MAIN_Exported_Constants
  * @{
  */ 
/**
  * @}
  */ 


/** @defgroup STM32F10x_LCD_Drive_MAIN_Exported_Variables
  * @{
  */ 
/**
  * @}
  */ 


/** @defgroup STM32F10x_LCD_Drive_MAIN_Exported_Functions
  * @{
  */ 
void Demo_Init(void);
void Delay(u32 nCount);
void Decrement_TimingDelay(void);
/**
  * @}
  */ 
#endif /* __MAIN_H */

/**
  * @}
  */ 

/**
  * @}
  */ 
/******************* (C) COPYRIGHT 2010 STMicroelectronics *****END OF FILE****/

