/**
  @page STM32F10x_LCDDrive AN3421 readme file
  
  @verbatim
  ******************** (C) COPYRIGHT 2010 STMicroelectronics *******************
  * @file FirmwareExamples/readme.txt 
  * @author   MCD Application Team
  * @version  V1.0.0
  * @date     07/07/2010
  * @brief    Description of the STM32 TFT-LCD direct drive firmware.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Description
   
This directory contains a set of sources files and pre-configured projects that 	
describes the STM32 TFT-LCD direct drive demonstration firmware running on the 
STM3210E-EVAL with the STEVAL-CCM002V1 daughter board which has a QVGA
TFT 3.5" (CT05350DW0000T (thin-film-transistor liquid crystal display)).


@par Directory contents 

 - inc: contains the header files
   - STM32F10x_LCDDrive/inc/lcd_driver.h          Header for lcd_driver.c
   - STM32F10x_LCDDrive/inc/stm32f10x_conf.h      Library Configuration files
   - STM32F10x_LCDDrive/inc/stm32f10x_it.h        Interrupt handlers header files
     
 - src: contains the source files 
   - STM32F10x_LCDDrive/src/stm32f10x_it.c        Interrupt handlers
   - STM32F10x_LCDDrive/src/main.c                Main program
   - STM32F10x_LCDDrive/src/lcd_driver.c          Contains the TFT-LCD driver functions 
   - STM32F10x_LCDDrive/src/lbacklight_control.c  contains the basic functions used to 
                                                  control the TFT-LCD backlight.

   
@par Hardware and Software environment

  - This example runs on STM32F10x devices embedding an FSMC thus High-Density 
    and XL-Density devices, 
  
  - This example has been tested with STMicroelectronics STM3210E-EVAL (High-Density) 
    with the STEVAL-CCM002V1 daughter board.
    
    Note: The daughter board order code is: STEVAL-CCM002V1.
          URL: http://ims.st.com/referencedesign/index.php#STEVAL-CCm002V1     

@par How to use it ?  

In order to load the code, you have do the following:

 - EWARMv5: 
    - Open the STM32F10x_LCDDrive.eww workspace
    - In the workspace toolbar select the project config:
        - STM3210E-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->Rebuild all
    - Load project image: Project->Debug
    - Run program: Debug->Go(F5)

   
 - HiTOP 
    - Open the HiTOP toolchain.
    - Browse to open the  STM32F10x_LCDDrive.htp
    - A "Download application" window is displayed, click "cancel".
    - Rebuild all files: Project->Rebuild all
    - Load project image : Click "ok" in the "Download application" window.
    - Run the "RESET_GO_MAIN" script to set the PC at the "main"
    - Run program: Debug->Go(F5).  

 - RIDE 
    - Open the STM32F10x_LCDDrive.rprj project
    - In the configuration toolbar(Project->properties) select the project config:
        - STM3210E-EVAL: to configure the project for STM32  High-density devices
    - Rebuild all files: Project->build project
    - Load project image: Debug->start(ctrl+D)
    - Run program: Debug->Run(ctrl+F9)

 - ARM-MDK 
    - Open the STM32F10x_LCDDrive.Uv2 project
    - In the build toolbar select the project config:
       - STM3210E-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->Rebuild all target files
    - Load project image: Debug->Start/Stop Debug Session
    - Run program: Debug->Run (F5)      
    
 - TrueSTUDIO
    - Open the TrueSTUDIO toolchain.
    - Click on File->Switch Workspace->Other and browse to TrueSTUDIO workspace 
      directory.
    - Click on File->Import, select General->'Existing Projects into Workspace' 
      and then click "Next". 
    - Browse to the TrueSTUDIO workspace directory and slelect the project:  
        - STM3210E-EVAL: to load the project.
    - Under Windows->Preferences->General->Workspace->Linked Resources, add 
      a variable path named "CurPath" which points to the "STM32F10x_LCDDrive" 
      folder which contains Libraries, Project and Utilities folders.      
    - Rebuild all project files: Select the project in the "Project explorer" 
      window then click on Project->build project menu.
    - Run program: Select the project in the "Project explorer" window then click 
      Run->Debug (F11)

@note
   - High-density devices are STM32F101xx and STM32F103xx microcontrollers where
     the Flash memory density ranges between 256 and 512 Kbytes.
   - XL-density devices are STM32F101xx and STM32F103xx microcontrollers where
     the Flash memory density ranges between 512 and 1024 Kbytes.
   
 * <h3><center>&copy; COPYRIGHT 2010 STMicroelectronics</center></h3>
 */
