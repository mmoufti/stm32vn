/**
  @page HDMI_CEC_Networking AN3127 HDMI CEC Networking Readme file
  
  @verbatim
  ******************** (C) COPYRIGHT 2010 STMicroelectronics *******************
  * @file    CEC/readme.txt 
  * @author  MCD Application Team
  * @version V1.1.0
  * @date    10/15/2010
  * @brief   Description of the AN3127 "CEC networking using STM32F100xx value 
  *          line microcontrollers".
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Description

This directory contains a set of sources files and pre-configured projects that
describes how to configure the HDMI-CEC peripheral and how to create 
CEC network providing a high level communication between three different 
devices using CEC protocol messages.


@par Directory contents 

 - "CEC\inc": contains the CEC firmware header files 
    - CEC/inc/main.h              Main header file
    - CEC/inc/cec_display.h       This file provides all the software function headers of the cec_display.c file.    
    - CEC/inc/stm32f10x_conf.h    Library Configuration file
    - CEC/inc/stm32f10x_it.h      Header for stm32f10x_it.c    

 - "CEC\MDK-ARM": contains pre-configured project for MDK-ARM toolchain

 - "CEC\RIDE": contains pre-configured project for RIDE toolchain

 - "CEC\EWARM": contains pre-configured project for EWARM toolchain

 - "CEC\HiTOP": contains pre-configured project for HiTOP toolchain
 
 - "CEC\TrueSTUDIO": contains pre-configured project for TrueSTUDIO toolchain 

 - "CEC\src": contains the CEC firmware source files
    - CEC/src/main.c              Main program
    - CEC/src/stm32f10x_it.c      Interrupt handlers
    - CEC/src/system_stm32f10x.c  STM32F10x system source file    
    - CEC/src/cec_display.c       This file provides the firmware which allows to display all CEC messages. 

@par Hardware and Software environment  

  - This example runs on STM32F10x High-Density Value line, Medium-Density Value line 
    and Low-Density Value line Devices.
  
  - This example has been tested with STMicroelectronics STM32100E-EVAL (STM32F10x 
    High-Density Value line) and STM32100B-EVAL (STM32F10x Medium-Density Value line)  
    evaluation boards and can be easily tailored to any other supported device 
    and development board.
    
  - STM32100E-EVAL :
    Connect the boards by using one of the two following alternatives:
    - A HDMI Cables between all boards HDMI-CEC connectors (CN2 or CN3)
    - Use a simple wire between all devices CEC Lines (PB.08), in this case don't 
      forget to connect all boards grounds together.
        
  - STM32100B-EVAL :
    Connect the boards by using one of the two following alternatives:
    - A HDMI Cables between all boards HDMI-CEC connectors (CN15 or CN16)
    - Use a simple wire between all devices CEC Lines (PB.08), in this case don't 
      forget to connect all boards grounds together.

@note
 - You can also use more than two CEC devices as much as you want (max 10 devices).
 - You can use also the STM3210B-EVAL with the UM0685 associated firmware as a
   CEC device. This configuration is available only when use a simple wire connected
   between STM3210B-EVAL PA.00 and STM32100B-EVAL PB.08 pins. Don't forget to
   add a 27KOhm pull-up resistor on the STM3210B-EVAL PA.00 and to to connect 
   all boards grounds together.
   
@par How to use it ?       
      
In order to load the IAP code, you have do the following:
 - EWARM
    - Open the CEC.eww workspace
    - In the workspace toolbar select the project config:
        - STM32100E-EVAL: to configure the project for STM32 High-density Value 
                          line devices
        - STM32100B-EVAL: to configure the project for STM32 Medium-density Value 
                          line devices
    - Rebuild all files: Project->Rebuild all
    - Load project image: Project->Debug
    - Run program: Debug->Go(F5)

 - RIDE 
    - Open the CEC.rprj project
    - In the configuration toolbar(Project->properties) select the project config:
        - STM32100E-EVAL: to configure the project for STM32 High-density Value 
                          line devices
        - STM32100B-EVAL: to configure the project for STM32 Medium-density Value 
                          line devices
    - Rebuild all files: Project->build project
    - Load project image: Debug->start(ctrl+D)
    - Run program: Debug->Run(ctrl+F9)
    
 - HiTOP 
    - Open the HiTOP toolchain.
    - Browse to open the CEC.htp
    - A "Download application" window is displayed, click "cancel".
    - Rebuild all files: Project->Rebuild all
    - Load project image : Click "ok" in the "Download application" window.
    - Run the "RESET_GO_MAIN" script to set the PC at the "main"
    - Run program: Debug->Go(F5).   

 - MDK-ARM 
    - Open the CEC.Uv2 project
    - In the build toolbar select the project config:
        - STM32100E-EVAL: to configure the project for STM32 High-density Value 
                          line devices
        - STM32100B-EVAL: to configure the project for STM32 Medium-density Value 
                          line devices
    - Rebuild all files: Project->Rebuild all target files
    - Load project image: Debug->Start/Stop Debug Session
    - Run program: Debug->Run (F5)

 - TrueSTUDIO 
    - Open the TrueSTUDIO toolchain.
    - Click on File->Switch Workspace->Other and browse to TrueSTUDIO workspace 
      directory.
    - Click on File->Import, select General->'Existing Projects into Workspace' 
      and then click "Next". 
    - Browse to the TrueSTUDIO workspace directory and select the project: 
        - STM32100E-EVAL: to configure the project for STM32 High-density Value 
                          line devices
        - STM32100B-EVAL: to configure the project for STM32 Medium-density Value 
                          line devices
    - Under Windows->Preferences->General->Workspace->Linked Resources, add 
      a variable path named "CurPath" which points to the folder containing
      "Libraries", "Project" and "Utilities" folders.
    - Rebuild all project files: Select the project in the "Project explorer" 
      window then click on Project->build project menu.
    - Run program: Select the project in the "Project explorer" window then click 
      Run->Debug (F11)
                 
    @note 
     - The free Lite version of TrueSTUDIO do not support printf() redirection.
       For more information, see "note.txt" under "STM32F10x_StdPeriph_Template\TrueSTUDIO".
 
@note
 - Low-density Value line devices are STM32F100xx microcontrollers where the 
   Flash memory density ranges between 16 and 32 Kbytes.
 - Low-density devices are STM32F101xx, STM32F102xx and STM32F103xx 
   microcontrollers where the Flash memory density ranges between 16 and 32 Kbytes.
 - Medium-density Value line devices are STM32F100xx microcontrollers where
   the Flash memory density ranges between 64 and 128 Kbytes.  
 - Medium-density devices are STM32F101xx, STM32F102xx and STM32F103xx 
   microcontrollers where the Flash memory density ranges between 64 and 128 Kbytes.
 - High-density Value line devices are STM32F100xx microcontrollers where the Flash
   memory density ranges between 256 and 512 Kbytes.
 - High-density devices are STM32F101xx and STM32F103xx microcontrollers where
   the Flash memory density ranges between 256 and 512 Kbytes.
 - Connectivity line devices are STM32F105xx and STM32F107xx microcontrollers.
 
 * <h2><center>&copy; COPYRIGHT 2010 STMicroelectronics</center></h2>
 */
